package com.alferdize.myapplication

import android.R.attr.rating
import android.R.id



class Thought(val name: String)
