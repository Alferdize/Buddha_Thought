package com.alferdize.myapplication

import android.annotation.SuppressLint
import android.os.Bundle
import android.widget.LinearLayout
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView


class ToughtActivity : AppCompatActivity() {

    @SuppressLint("WrongConstant")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.container)

        //getting recyclerview from xml
        val recyclerView = findViewById(R.id.recyclerView) as RecyclerView

        //adding a layoutmanager
        recyclerView.layoutManager = LinearLayoutManager(this, LinearLayout.VERTICAL, false)


        //crating an arraylist to store users using the data class user
        val users = ArrayList<Thought>()

        //adding some dummy data to the list
        users.add(Thought("Belal Khan"))
        users.add(Thought("Ramiz Khan"))
        users.add(Thought("Faiz Khan"))
        users.add(Thought("Yashar Khan"))

        //creating our adapter
        val adapter = ThoughtAdapter(users)

        //now adding the adapter to recyclerview
        recyclerView.adapter = adapter
    }
}